#include "ClientApp.h"


int main(){
    ClientApp app;
    app.handleEvents();
    return 0;
}